## PyWatermark

A python library to watermark your images!