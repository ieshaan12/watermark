from PyWatermark.watermark import waterMarkImages, getAvailableFonts

__author__ = "Ieshaan Saxena"
__version__ = "0.1.0"