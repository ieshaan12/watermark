FONT_MAP = {
    "Bangers" : "Bangers-Regular.ttf",
    "MerriweatherSans" : "MerriweatherSans-Regular.ttf",
    "Oswald" : "Oswald-Regular.ttf",
    "Raleway" : "Raleway-Regular.ttf",
    "Roboto" : "Roboto-Regular.ttf",
}

AVAILABLE_FONTS = {
    "Bangers",
    "MerriweatherSans",
    "Oswald",
    "Raleway",
    "Roboto"
}