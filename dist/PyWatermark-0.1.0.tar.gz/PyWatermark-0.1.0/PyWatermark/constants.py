SIZE_CONSTANTS = {
    "XS": 0.8,
    "S": 1.2,
    "M": 1.4,
    "L": 1.8,
    "XL": 2.5,
    "XXL": 3
}

POSITION_CONSTANTS = {
    "BR",
    "TR",
    "TL",
    "BL"
}